import React, {useEffect,useState} from "react";
function UsersList(){
   const[users,setUsers]=useState([]);
   const [loading,setLoading]=useState(true);
   useEffect(()=>{
    async function fetchData() {
        const res=await
        fetch("https://jsonplaceholder.typicode.com/users");
        const data=await res.json();
        setUsers(data);
        setLoading(false);
    }
    fetchData();
   },[]);
   return (
    <div>
        <h2>Users List</h2>
        {loading ?(
        <p>loading...</p>
        ):(
            <ul>
                {users.map((user)=>(
                    <div>
                        <li key={user.id}>{user.name}</li>
                        <img src={user.image}/>
                    </div>
                ))}
            </ul>
   )}
    </div>
   );
}
export default UsersList