import React from 'react'

function HtmlForm() {
  return (
    <div>
      <form>
        <input type="email" id="user"/>
        <button>Submit</button>
      </form>
      <input type="email" id="user"/>
      <p id="p"></p>
      
    </div>
  )
}

export default HtmlForm
