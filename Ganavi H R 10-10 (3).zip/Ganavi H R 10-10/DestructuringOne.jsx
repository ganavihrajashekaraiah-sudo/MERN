import React from 'react'

function Car1({color}) {
  return (
    <h2> My car is {color}!</h2>
    
  );
}

export default Car1;
