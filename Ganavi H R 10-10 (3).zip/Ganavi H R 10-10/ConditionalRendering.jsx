import React from 'react'

function Pass(){
    return (
    <div>Congratulations!</div>
    )
}
function Fail(){
    return(
        <div>Better Luck Next Time!</div>
    )
}
{/*//function Check(props){
    const isresult=props.isresult;
    if(isresult=="True"){
        return <Pass/>;
    }
    

    if(isresult==="Fail"){
    return <Fail/>;
}
}//*/}
function Check(props){
    const isresult=props.isresult;
    return(
        <>
        {isresult ? <Pass/> : <Fail/>}
        </>
    );
}
export default Check