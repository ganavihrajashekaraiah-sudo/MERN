import React from 'react'
import { Link } from 'react-router-dom'
function Index() {
  return (
    <div>
      <h1> This is a index page</h1>
      <nav>
        <Link to='/home'>HomePage | |</Link>
        <Link to='/about'>AboutUS | |</Link>
        <Link to ='/contact'>ContactUs | |</Link>
      </nav>
    </div>
  )
}

export default Index
