import React from 'react'

function Car(props){
  return (
    
    <div>
      {props.brand && <h1> My car is a {props.brand}!</h1>}
    </div>
  );
}

export default Car

