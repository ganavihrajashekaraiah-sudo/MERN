import React from 'react'
import HtmlForm from './HtmlForm'
import ControlledForm from './ControlledForm'
import TwowayBinding from './TwowayBinding'
import FormValidation from './FormValidation'
function App() {
  return (
    <div>
      <HtmlForm/>
      <ControlledForm/>
      <TwowayBinding/>
      <FormValidation/>
    </div>
  )
}

export default App
