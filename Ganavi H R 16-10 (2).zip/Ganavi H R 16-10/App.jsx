import { useState } from 'react'
import './App.css'
import UseEffect from './UseEffect'
import Counter from './Counter'
import Cleanup from './CleanUp'
import UsersList from './UsersList'
import { Greeting } from './Css'
import { Temperature } from './Css'

function App() {
  return (
      <div>
        <UseEffect/>
        <Counter/>
        <Cleanup/> 
        <UsersList/>
        <Greeting/>
        <Temperature/>
      </div>
      
  )
}

export default App