import React from 'react'

function FirstComponent(ganavi) {
  return (
    <div>
      <h1>FirstComponent {ganavi.name}</h1>
      <SecondComponent phno="7894561223"/>
    </div>
  )
}

function SecondComponent(ganavi1) {
  return (
    <div>
      SecondComponent {ganavi1.phno}
    </div>
  )
}

export default FirstComponent