import React, { useState } from 'react'

function FormValidation(){
    const [email,setEmail]=useState("");
    const [error,setError]=useState("");
    const [number,setNum]=useState("");
    const [errorr,setError2]=useState("");
   
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(!email.includes("@")){
            setError("Please enter a valid email!");
        }else{
            setError("");
            alert(`Email Submitted:${email}`);
        }
        if(!number.length> 10 && number.length< 10){
            
            setError2("");
            alert(`Number Submitted:${number}`);
        }else{
            setError2("Please enter a valid Number!");
        }
    };
    return(
        <form onSubmit={handleSubmit}>
            <input type="text"
             value={email}
              onChange={(e)=>setEmail(e.target.value)}
            />
            <input type="number" 
            value={number}
             onChange={(e)=>setNum(e.target.value)}
             />
                <button type="submit">Submit</button>
            {error && <p style={{color:"red"}}>{errorr}</p>}
         
            {error && <p style={{color:"red"}}>{error}</p>}
        </form>
    );
}
export default FormValidation