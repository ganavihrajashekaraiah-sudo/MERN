import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
import Parent from './PropsChildern'
function App() {
  return (
    <div>
      <FirstComponent name="Ganavi" />
      <FirstComponent name="Ganavi" />
      <FirstComponent name="Ganavi" />
      <Fruit/>
      <Parent/>
    </div>
  )
}

export default App;