import React from 'react';

class Fruit extends React.Component{
    render(){
        return <h1>A class component</h1>
    }
}
export default Fruit;