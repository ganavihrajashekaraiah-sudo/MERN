import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
//import Parent from './PropsChildern'
import  Check from './ConditionalRendering'
import Car from './LogicalOperator'
import Car1 from './DestructuringOne'
import Car2 from './DestructuringTwo'
import Parent from'./PropDrilling'
function App() {
  return (
    <div>
      <FirstComponent name="Ganavi" />
      <FirstComponent name="Ganavi" />
      <FirstComponent name="Ganavi" />
      <Fruit/>
      <Parent/>
     {/*//<Argument name="Kavya" phno="88"/>*/}
      <Check isresult='Fail'/>
      <Car brand="Ford"/>
      <Car1 color="Red"/>
      <Car2 brand="Ford" model="Mustang" />
      <Parent  studentName="Ganavi"/>
    
      </div>
  )
}

export default App;